﻿namespace CalculatorLib;

public class Calculator
{
  public double Add(double a, double b)
  {
    return a + b;
  }
}
