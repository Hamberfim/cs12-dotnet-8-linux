﻿using static System.Console;

WriteLine("* Top-level functions example");

WhatsMyNamespace(); // Call the function.
