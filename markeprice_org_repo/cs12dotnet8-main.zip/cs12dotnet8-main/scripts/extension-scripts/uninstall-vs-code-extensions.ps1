code --uninstall-extension ms-dotnettools.csdevkit
code --uninstall-extension ms-dotnettools.csharp
code --uninstall-extension ms-dotnettools.vscodeintellicode-csharp
code --uninstall-extension ms-dotnettools.dotnet-interactive-vscode
code --uninstall-extension tintoy.msbuild-project-tools
code --uninstall-extension humao.rest-client
code --uninstall-extension icsharpcode.ilspy-vscode
